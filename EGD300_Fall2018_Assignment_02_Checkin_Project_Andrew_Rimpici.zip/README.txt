================================================================================================
README.txt
================================================================================================

Andrew Rimpici
Game Technology II
Assignment 2 Check-In
9/20/2018

Github: https://github.com/Andy608/GameTechRepo

================================================================================================

About

- The scene I have created my map in is called the "Level" scene.
- In the scene, there is an open area for the character to move around in that is surrounded by
  trees. In the future, zombies will spawn from inside the forest and the player will have to
  stay alive for as long as possible.

================================================================================================

Struggles

- Getting the Navmesh to work properly in only my desired play area. (Inside the forest).

================================================================================================